import java.util.ArrayList;
import java.util.Scanner;
	
/**
 * 
 * Clasa principala
 * 
 * @author Florin
 *
 */

public class Bot {

	private static Scanner read;
	// scorile pentru fiecare mutare posibila
	final static int[][] tabla_scoruri = {
		{0, 0 , 0, 290, 295, 290, 0, 0, 0},
		{265, 270, 275, 280, 285, 280, 275, 270, 265},
		{240, 245, 250, 255, 260, 255, 250, 245, 240},
		{215, 220, 225, 230, 235, 230, 225, 220, 215},
		{190, 195, 200, 205, 210, 205, 200, 195, 190},
		{165, 170, 175, 180, 185, 180, 175, 170, 165},
		{140, 145, 150, 155, 160, 155, 150, 145, 140},
		{115, 120, 125, 130, 135, 130, 125, 120, 115},
		{90, 95, 100, 105, 110, 105, 100, 95, 90},
		{65, 70, 75, 80, 85, 80, 75, 70, 65},
		{40, 45, 50, 55, 60, 55, 50, 45, 40},
		{15, 20, 25, 30, 35, 30, 25, 20, 15},
		{0, 0, 0, 5, 10, 5, 0, 0, 0}
	};
	
    private static final int INF = 999999;
    private static final int MAXDEPTH = 3;
    Move mutare_buna; // mutarea care o consider buna la un moment dat
    
    // true - pentru debugging
    private static boolean afisari_mesaje = false;
    
    /**
     * 
     * Where black magic happens.
     * Metoda care-mi calculeaza scorul aferent fiecarei mutari.
     * 
     * @param teren
     * Terenul de joc
     * 
     * @param play_as
     * Jucatorul pentru care analizem mutarea curenta.
     * 
     * @param alpha
     * @param beta
     * 
     * @param depth
     * Adancimea la care s-a ajuns.
     * 
     * @param start
     * Timpul la care am intrat in recursivitate
     * 
     * @return
     */
    
	public int alphaBeta(Teren teren, PLAYER play_as, int alpha, int beta, int depth, long start) {
		
		int score;	
		Move pozitie_veche = teren.getCurentPossion();
		
		PLAYER other_player;
    	if (play_as == PLAYER.PLAY_AS_N)
    		other_player = PLAYER.PLAY_AS_S;
    	else
    		other_player = PLAYER.PLAY_AS_N;
		
    	int scor_din_tabel = tabla_scoruri[pozitie_veche.getX()][pozitie_veche.getY()];
    	
    	if (play_as == PLAYER.PLAY_AS_S)
    		scor_din_tabel = scor_din_tabel * (-1);
    	
    	scor_din_tabel = scor_din_tabel - Math.abs(pozitie_veche.getY() - 4) - pozitie_veche.getX();
    	
    	if (teren.GameOver()) return scor_din_tabel;
    	if (depth <= 0) return scor_din_tabel;
    	
    	long curent = System.currentTimeMillis();
    	
    	if ((curent - start > 50) && (play_as == PLAYER.PLAY_AS_N)) return scor_din_tabel * 2;
    	if ((curent - start > 50) && (play_as == PLAYER.PLAY_AS_S)) return scor_din_tabel / 2;
    	
		Move aux;
		
		for (Move m : teren.allPossibleMoves()) {
			
			// urmeaza sa setez mutarea curenta
			
			ArrayList<Move> mutari = new ArrayList<Move>();
			aux = m;

			while (true) {
				
				mutari.add(0, aux);
				aux = aux.getParinte();
				
				if (aux == null) break;
				
			}
			
			for (Move m1 : mutari)
				teren.setMove(m1, teren.getCurentPossion());
			
			// s-a terminat de setat mutarea curenta
			
			score = -alphaBeta(teren, other_player, -beta, -alpha, depth - 1, start);
			
			// sterg mutarea curenta din teren pentru ca am termina de analizat
			
			mutari.add(0, pozitie_veche);
			for (int j = mutari.size() - 1; j > 0; j--) {
				
				teren.removeMove(mutari.get(j), mutari.get(j-1));
				
			}
			
			// aici s-a termiant de sters mutarea din teren
			
			if (score >= beta)
				return beta;
			
			if (score > alpha)
				alpha = score;
			
		}
		
		return alpha;
		
	}
	
	/**
	 * 
	 * Metoda care-mi selecteaza mutarea cea mai buna pentru mine in functie de scorul dat de "alfabeta"
	 * 
	 * @param teren
	 */
	
	public void aflaMutare(Teren teren) {
		
		int score, max = -INF;
		
		Move old = teren.getCurentPossion();
		
		if (afisari_mesaje)
			for (Move m : teren.allPossibleMoves())
				System.out.println("Mutare Posibila: " + m);
		
		// am sa evaluez numai mutarile care se indeparteaza de poarta mea
		boolean nu_mai_evalua = false;
		
		for (Move m : teren.allPossibleMoves()) {
			
			// daca mutarea care pot s-o fac se indeparteaza de poarta mea
			if (m.getX() > old.getX()) {
				nu_mai_evalua = true;
			} else
				nu_mai_evalua = false; // o evaluez
			
			if (!nu_mai_evalua) {
				
				// setez mutarea cea noua in teren
				
				ArrayList<Move> mutari = new ArrayList<Move>();
				Move aux = m;
			
				while (true) {
					
					mutari.add(0, aux);
					aux = aux.getParinte();
				
					if (aux == null) break;
				
				}
			
				for (Move mutare_avantajoasa : mutari)
					teren.setMove(mutare_avantajoasa, teren.getCurentPossion());
			
				// aici am terminat de setat mutarea cea noua in teren
				
				// salvez timpul la care intru in recursivitate
				long start = System.currentTimeMillis();
			
				score = -alphaBeta(teren, PLAYER.PLAY_AS_S, -INF, INF, MAXDEPTH, start);
			
				// daca scorul imi este favorabil mine
				if (score > max) {
					max = score;
					this.mutare_buna = m; // salvez mutarea
				}
			
				// urmeaza sa sterg din teren mutarea pe care tocmai am analizat-o
				
				mutari.add(0, old);
				for (int j = mutari.size() - 1; j > 0; j--)
					teren.removeMove(mutari.get(j), mutari.get(j-1));
			
				// aici s-a termiant de sters
				
			} else 
				score = -1; // daca n-am evaluat mutarea, aceasta are scor negativ
	
			if (afisari_mesaje)
				System.out.println(score + ": " + m);
			
		}
		
		if (afisari_mesaje)
			System.out.println("scor maxim: " + max);
		
	}
	
	/**
	 * 
	 * Metoda care-mi returneaza directia pe care trebuie s-o afisez.
	 * 
	 * @param new_move
	 * Mutarea pe care urmeaza s-o fac.
	 * 
	 * @param old_move
	 * Locul de unde plec.
	 * 
	 * @return
	 * Un integer [0..7] reprezentand {N, NE, E, SE, ...}
	 * 
	 */
	
	public int mutare(Move new_move, Move old_move) {
		
		// N
		if ((new_move.getX() < old_move.getX()) && (new_move.getY() == old_move.getY())) return 0;
		
		// NE
		if ((new_move.getX() < old_move.getX()) && (new_move.getY() > old_move.getY())) return 1;
		
		// E
		if ((new_move.getX() == old_move.getX()) && (new_move.getY() > old_move.getY())) return 2;
		
		// SE
		if ((new_move.getX() > old_move.getX()) && (new_move.getY() > old_move.getY())) return 3;
		
		// S
		if ((new_move.getX() > old_move.getX()) && (new_move.getY() == old_move.getY())) return 4;
		
		// SV
		if ((new_move.getX() > old_move.getX()) && (new_move.getY() < old_move.getY())) return 5;
		
		// V
		if ((new_move.getX() == old_move.getX()) && (new_move.getY() < old_move.getY())) return 6;
		
		// NV
		if ((new_move.getX() < old_move.getX()) && (new_move.getY() < old_move.getY())) return 7;
		
		return 0;
		
	}
	
	/**
	 * 
	 * Metoda main
	 * 
	 * @param args
	 * Lista de argumente
	 * 
	 */
	
	public static void main(String[] args) {

		read = new Scanner(System.in);
		String tip_mesaj;
		int numar_mutari; // numarul de mutari pe care urmeaza sa le fac eu
		int[] mutari; // mutarile pe care le-a facut adversarul
		
		Teren teren = new Teren();
		Bot bot = new Bot();

		while (true) { // cat timp meciu e in desfasurare
			
			tip_mesaj = read.next(); // citesc tipul mesajului
		
			if (tip_mesaj.equals("F")) break; // daca meciu s-a termin opresc programul
			
			if (tip_mesaj.equals("S")) { // daca eu mut primul
				
				teren.firstMove();
				
				System.out.println("M 1 0"); // mut in nord
			
			} else if (tip_mesaj.equals("M")) {
			
				numar_mutari = read.nextInt(); // numarul de mutari ale adversarului
				mutari = new int[numar_mutari];
			
				for (int i = 0; i < numar_mutari; i++) { // le citesc
					mutari[i] = read.nextInt();
					teren.setEnemyMoves(mutari[i]); // si le setez in teren
				}
				
				// aflu mutarea cea mai buna pentru mine
				bot.aflaMutare(teren);
				
				Move aux = bot.mutare_buna;
				
				// urmeaza sa setez mutarea gasita de mine in teren
				
				ArrayList<Move> moves = new ArrayList<Move>();
				
				int cate = 0;
				
				while (true) {
					
					cate++;
					moves.add(0, aux);
					aux = aux.getParinte();
					
					if (aux == null) break;
					
				}
				
				String mesaj = "M " + cate;
				
				// e posibil sa fie o mutare care sa fie deviata in alta si tot asa
				// si setez in teren toate mutarile
				
				for (Move m : moves) { 
					
					int coord = bot.mutare(m, teren.getCurentPossion());
					teren.setEnemyMoves(coord);
					
					mesaj = mesaj + " " + coord;
					
				}
				
				System.out.println(mesaj);
				
				if (afisari_mesaje)
					System.out.println(bot.mutare_buna);
				
			}
		}

	}

}
