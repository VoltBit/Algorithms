import java.util.ArrayList;

/**
 * 
 * Clasa pentru terenul de fotbal.
 * 
 * @author Florin
 *
 */

public class Teren {

	// graful de mutari vazut ca o matrice
	private int[][] mutari_facute = new int[117][117];
	private Move pozitie_curenta;
	
	/**
	 * 
	 * In cazul in care eu sunt primul care muta, am sa mut spre nord.
	 * 
	 */
	
	public void firstMove() {
		
		pozitie_curenta = new Move(5, 4);
		
		int i, j;
		i = 9 * 5 + 4;
		j = 9 * 6 + 4;
		mutari_facute[i][j] = 1;
		mutari_facute[j][i] = 1;
		
	}
	
	/**
	 * 
	 * Constructor pentru terenul de fotbal.
	 * 
	 */
	
	public Teren() {
		
		this.pozitie_curenta = new Move(6, 4);
		
	}

	/**
	 * 
	 * Metoda care-mi returneaza pozitia din teren in care se afla mingea.
	 * 
	 * @return
	 * Pozitia mingii din teren.
	 * 
	 */
	
	public Move getCurentPossion() {
		return pozitie_curenta;
	}
	
	/**
	 * 
	 * Metoda care-mi verifica daca o mutare este valida.
	 * 
	 * @param new_move
	 * Mutarea care vreau s-o verific.
	 * 
	 * @param old_move
	 * Mutarea cea veche (sau pozitia curenta a mingii in teren).
	 * 
	 * @return
	 * true / false dupa caz
	 * 
	 */
	
	public boolean isMoveValid(Move new_move, Move old_move) {
		
		// sa nu-mi ajunga cumva in afara terenului
		if ((new_move.getX() < 0) || (new_move.getX() > 12)) return false;
		if ((new_move.getY() < 0) || (new_move.getY() > 8)) return false;
		
		if ((new_move.getX() == 0) && (old_move.getX() == 1) && (new_move.getY() != 4)) return false;
		
		// sa nu-mi ajunga in alea 6 casute din afara terenului de joc aferente poartei din nord
		if ((new_move.getX() == 0) && (new_move.getY() < 3)) return false;
		if ((new_move.getX() == 0) && (new_move.getY() > 5)) return false;
		
		// sa nu-mi ajunga in alea 6 casute din afara terenului de joc aferente poartei din sud
		if ((new_move.getX() == 12) && (new_move.getY() < 3)) return false;
		if ((new_move.getX() == 12) && (new_move.getY() > 5)) return false;
		
		// sa nu-mi mearga pe marginile verticale ale terenului
		if ((new_move.getY() == old_move.getY()) && (old_move.getY() == 0)) return false;
		if ((new_move.getY() == old_move.getY()) && (old_move.getY() == 8)) return false;
		
		// sa nu-mi mearga pe marginile orizontale ale terenului aferente poartei din nord
		if ((new_move.getX() == old_move.getX()) && (old_move.getX() == 1) && (new_move.getY() != 4)) return false;
		
		// sa nu-mi mearga pe marginile orizontale ale terenului aferente poartei din sud
		if ((new_move.getX() == old_move.getX()) && (old_move.getX() == 11) && (new_move.getY() != 4)) return false;
		
		// altfel, daca mutarea e valida
		int i = 9 * new_move.getX() + new_move.getY();
		int j = 9 * old_move.getX() + old_move.getY();
		
		// verifica sa nu o mai fi facut deja
		if (mutari_facute[i][j] == 1) return false;
		if (mutari_facute[j][i] == 1) return false;
		
		// am ajuns aici daca n-am mai facut aceasta mutare
		return true;
		
	}
	
	/**
	 * 
	 * Metoda care-mi seteaza o noua mutare in graful de mutari.
	 * 
	 * @param new_move
	 * Mutarea cea noua.
	 * 
	 * @param old_move
	 * Pozitia cea veche.
	 * 
	 */
	
	public void setMove(Move new_move, Move old_move) {
		
		int i = 9 * new_move.getX() + new_move.getY();
		int j = 9 * old_move.getX() + old_move.getY();
		
		mutari_facute[i][j] = 1;
		mutari_facute[j][i] = 1;
		
		this.pozitie_curenta = new_move;
		
	}
	
	/**
	 * 
	 * Metoda care-mi sterge o mutare din teren.
	 * 
	 * @param new_move
	 * Mutarea care o sterg.
	 * 
	 * @param old_move
	 * Mutarea care va deveni pozitia curenta a mingii.
	 * 
	 */
	
	public void removeMove(Move new_move, Move old_move) {
		
		int i = 9 * new_move.getX() + new_move.getY();
		int j = 9 * old_move.getX() + old_move.getY();
		
		mutari_facute[i][j] = 0;
		mutari_facute[j][i] = 0;
		
		this.pozitie_curenta = old_move;
		
	}
	
	/**
	 * 
	 * Metoda care-mi seteaza in graf mutarile adversarului.
	 * 
	 * @param move
	 * Un integer [0..7] reprezentand {N, NE, E, ...}
	 * 
	 */
	
	public void setEnemyMoves(int move) {
		
		// imi aflu coordonatele noii mutari
		
		int i = 0, j = 0;
		
		if ((move == 7) || (move == 0) || (move == 1)) i = -1;
		if ((move == 5) || (move == 4) || (move == 3)) i = 1;
		
		if ((move == 7) || (move == 6) || (move == 5)) j = -1;
		if ((move == 1) || (move == 2) || (move == 3)) j = 1;
		
		// din pozitia curenta se scade / aduna 1 sau 0 de pe X si Y
		
		Move next_move = new Move(this.pozitie_curenta.getX() + i, this.pozitie_curenta.getY() + j);
		
		setMove(next_move, this.pozitie_curenta);
		
	}
	
	/**
	 * 
	 * Metoda care-mi genereaza toate mutarile pozibile de la pozitia curenta.
	 * Mutarile au lungime de 1 - o linie. Nu sunt mutari de 2-3 (sau mai multe linii). Pe acestea urmeaza sa le generez mai tarziu.
	 * 
	 * @return
	 * Un vector cu mutarile posibile.
	 * 
	 */
	
	public ArrayList<Move> possibleMoves() {
		
		ArrayList<Move> moves = new ArrayList<Move>();
		
		if (GameOver()) return moves;
		
		Move pozitia_curenta = this.pozitie_curenta;
	
		Move potentiala_mutare_valida;
		
		// N
		potentiala_mutare_valida = new Move(pozitia_curenta.getX() - 1, pozitia_curenta.getY());
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// NE
		potentiala_mutare_valida = new Move(pozitia_curenta.getX() - 1, pozitia_curenta.getY() + 1);
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// E
		potentiala_mutare_valida = new Move(pozitia_curenta.getX(), pozitia_curenta.getY() + 1);
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// SE
		potentiala_mutare_valida = new Move(pozitia_curenta.getX() + 1, pozitia_curenta.getY() + 1);
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// S
		potentiala_mutare_valida = new Move(pozitia_curenta.getX() + 1, pozitia_curenta.getY());
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// SV
		potentiala_mutare_valida = new Move(pozitia_curenta.getX() + 1, pozitia_curenta.getY() - 1);
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// V
		potentiala_mutare_valida = new Move(pozitia_curenta.getX(), pozitia_curenta.getY() - 1);
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		// NV
		potentiala_mutare_valida = new Move(pozitia_curenta.getX() - 1, pozitia_curenta.getY() - 1);
		if (isMoveValid(potentiala_mutare_valida, pozitia_curenta)) moves.add(potentiala_mutare_valida);
		
		return moves;
		
	}
	
	/**
	 * 
	 * Metoda care-mi genereaza toate mutarile posibile de la pozitia curenta.
	 * Aceasta cuprinde si mutarile mutarilor. Deci pot sa am o mutare de 2-3 (sau mai multe) segmente.
	 * 
	 * @return
	 * Un vector cu mutarile posibile.
	 * 
	 */
	
	public ArrayList<Move> allPossibleMoves() {
		
		// mutarile care nu se deviaza
		ArrayList<Move> mutari_bune = new ArrayList<Move>();
		
		// mutarile ca se deviaza - adica mai am dreptul la o inca o mutare
		ArrayList<Move> mutari_care_se_deviaza = new ArrayList<Move>();
		
		// sortez primul rand de mutari posibile
		for (Move m : possibleMoves()) {
			if (anotherMove(m))
				mutari_care_se_deviaza.add(m);
			else
				mutari_bune.add(m);
		}

		Move curent;
		Move aux;
		Move old = this.pozitie_curenta;
		
		// apoi din mutarile care se deviaza, vad ce mutari posibile am
		// daca dintr-o mutare deviata dau in alta deviata, am sa intru iar in "recurenta" (de fapt, algoritmul e iterativ).
		
		while (!mutari_care_se_deviaza.isEmpty()) {
			
			// scot prima mutare din coada
			curent = mutari_care_se_deviaza.remove(0);
			aux = curent;
			
			// si o setez in teren
			
			ArrayList<Move> mutari = new ArrayList<Move>();
			
			while (true) { // setez in teren si mutarile deviate pana am ajuns la mutarea curenta
				
				mutari.add(0, aux);
				aux = aux.getParinte();
				
				if (aux == null) break;
				
			}
			
			for (Move mutare_noua : mutari)
				setMove(mutare_noua, this.pozitie_curenta);
			
			// aici s-a terminat setarea in teren a mutarii curente
				
			// pentru fiecare mutare posibila
			
			for (Move m : possibleMoves()) {
				
				m.addParinte(curent); // setez ca parinte mutarea precedenta // e un fel de parcurgere DFS
				
				// si vad unde se incadreaza
				if (anotherMove(m)) {
					mutari_care_se_deviaza.add(m);
				} else if (!mutari_bune.contains(m))
					mutari_bune.add(0, m);
				
			}
			
			// apoi urmeaza sa sterg mutarea setata anterior in graf ca sa fac loc pentru urmatoarea
			
			mutari.add(0, old);
			for (int j = mutari.size() - 1; j > 0; j--)
				removeMove(mutari.get(j), mutari.get(j-1));
			
		}
		
		return mutari_bune;
		
	}
	
	/**
	 * 
	 * Metoda care-mi verfica daca mai am dreptul la o mutare.
	 * Ea se apeleaza pana a fi setata noua mutare.
	 * 
	 * @param mutarea_pe_care_urmeaza_so_fac
	 * Mutarea care vreau s-o fac.
	 * 
	 * @return
	 * true / false dupa caz
	 * 
	 */
	
	public boolean anotherMove(Move mutarea_pe_care_urmeaza_so_fac) {
		
		// daca imi atinge marginile verticale
		if (mutarea_pe_care_urmeaza_so_fac.getY() == 0) return true;
		if (mutarea_pe_care_urmeaza_so_fac.getY() == 8) return true;
		
		// daca imi atinge marginile orizontale
		if ((mutarea_pe_care_urmeaza_so_fac.getX() == 1) && (mutarea_pe_care_urmeaza_so_fac.getY() != 4)) return true;
		if ((mutarea_pe_care_urmeaza_so_fac.getX() == 11) && (mutarea_pe_care_urmeaza_so_fac.getY() !=4)) return true;
		
		// daca a mai plecat sau sosit ceva din mutarea pe care vreau s-o fac
		int k = 9 * mutarea_pe_care_urmeaza_so_fac.getX() + mutarea_pe_care_urmeaza_so_fac.getY();
		for (int i = 0; i < 117; i++)
			if (mutari_facute[k][i] == 1) return true;
		
		// daca am ajuns aici in seamna ca nu mai am dreptul la o inca o mutare
		return false;
		
	}
	
	/**
	 * 
	 * Metoda care-mi verifica daca jocul s-a terminat.
	 * 
	 * @return
	 * true / false dupa caz.
	 * 
	 */
	
	public boolean GameOver() {
		
		if (this.pozitie_curenta.getX() == 0) return true;
		if (this.pozitie_curenta.getX() == 12) return true;
		
		return false;
	}
	
}
