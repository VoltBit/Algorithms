Mi-am reprezentat terenul sub foarma unui graf, si folosesc o matrice cu scorurile aferente fiecarei mutari.
Fiecare punct in care pot sa ajung in teren are in matrice un element. Terenul este de 10x8 + 2 porti => matricea are 13x9 sub urmatoarea forma.

0 0 0 1 1 1 0 0 0
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
1 1 1 1 1 1 1 1 1
0 0 0 1 1 1 0 0 0

1 - reprezinta punctele in care pot sa mut
0 - reprezinta punctele in afara terenului de joc

Acum acest teren este vazut ca un graf. Am reprezentat graful prin matricea de adiacenta. Va veni o matrice de 117x117. 13*9 = 117
Mai sunt vreo 12 noduri pe care nu le folosesc (cele din afara terenului), dar le-am pastrat pentru a-mi fi mai usor la indici.

0	1	2	3	4	5	6	7	8	
9	10	11	12	13	14	15	16	17	
18	19	20	21	22	23	24	25	26	
27	28	29	30	31	32	33	34	35	
36	37	38	39	40	41	42	43	44	
45	46	47	48	49	50	51	52	53	
54	55	56	57	58	59	60	61	62	
63	64	65	66	67	68	69	70	71	
72	73	74	75	76	77	78	79	80	
81	82	83	84	85	86	87	88	89	
90	91	92	93	94	95	96	97	98	
99	100	101	102	103	104	105	106	107	
108	109	110	111	112	113	114	115	116

Fiecare mutare din terenul de mai sus reprezinta un nod in graf. Nodurile sunt de la 0 la 116. Indicele nodului aferent mutarii se afla foarte usor dupa urmatoarea formula:

int i = 9 * move.getX() + move.getY();

Daca initial mingea se afla pe pozitia (6,4), iar eu vreau sa mut spre nord (5,4) am sa salvez mutarea in graf in felul urmator:
	nod_pozitie_veche = 9 * 6 + 4 = 58
	nod_pozitie_noua = 9 * 5 + 4 = 49

Deci, am muchie de la pozitia noua la pozitia veche si invers.
	graf[nod_pozitie_veche][nod_pozitie_noua] = 1;
	graf[nod_pozitie_noua][nod_pozitie_veche] = 1;

In rezolvarea temei am folosit un algoritm Minimax (mai exact un Alpha-beta pruning, varianta negamax). Fiecarei mutari din teren i-am atribuit un scor dupa cum urmeaza:

final static int[][] tabla_scoruri = {
	{0, 0 , 0, 290, 295, 290, 0, 0, 0},
	{265, 270, 275, 280, 285, 280, 275, 270, 265},
	{240, 245, 250, 255, 260, 255, 250, 245, 240},
	{215, 220, 225, 230, 235, 230, 225, 220, 215},
	{190, 195, 200, 205, 210, 205, 200, 195, 190},	
	{165, 170, 175, 180, 185, 180, 175, 170, 165},
	{140, 145, 150, 155, 160, 155, 150, 145, 140},
	{115, 120, 125, 130, 135, 130, 125, 120, 115},
	{90, 95, 100, 105, 110, 105, 100, 95, 90},
	{65, 70, 75, 80, 85, 80, 75, 70, 65},
	{40, 45, 50, 55, 60, 55, 50, 45, 40},
	{15, 20, 25, 30, 35, 30, 25, 20, 15},
	{0, 0, 0, 5, 10, 5, 0, 0, 0}
};

Aceasta nu este scorul final aferent unui mutari. Se mai schimba un pic, dar am sa explic un pic mai in colo.

Meciul incepe din mijloc (scor 160), iar eu atac spre nord. Cu cat ma apropi mai mult de poarta adversa trebuie sa am un scor mai mare, iar cu cat ma departez mai mult de centru scorul scade (simetric pe stanga si pe dreapta).

Initial, trebuie sa-mi generez toate pozitile din care pot sa ajung din pozitia curenta. Apoi pe fiecare pozitie generata am sa aplica alfabeta pentru a-i calcula scorul aferent si sa verific care-i cea mai buna.

Pozitiile in care pot sa ajung sunt generata in felul urmator:

	Prima oara vad in din pozitia curenta in ce pozitii pot sa ajung (maxim 8) - N, NE, E, SE .. NV
	Sortez aceste mutari in 2 vectori:
		- mutari care nu pot sa ma devieze
		- mutari care-mi dau dreptul sa mai fac inca o mutare

	Apoi, fiecare mutare care-mi mai da dreptul al inca o mutare ii generez mutarile aferente - maxim 8 - N, NE, E, SE .. NV
		si se sortez si pe aceste in mutari care-mi mai dau dreptul la alta mutare sau mutari care se opresc acolo

	Pot sa am ceva de forma:
		[ 6, 5 ] : [ 6, 4 ] : [ 6, 3 ] : [ 6, 2 ] : null

		Parcurgem de la coada la cap
			plec din pozitia curenta - null
			ajung in [6,2] care ma deviaza in [6,3]
			[6,3] ma deviaza [6,4] si tot asa

		Si in felul acesta eu in vectorul de mutari posibile am toate pozitiile in care pot sa ajung dintr-o anumita pozitie. Este un fel de DFS.
	
		Exemplu:

			Mutare Posibila: [ 7, 5 ] : [ 6, 4 ] : [ 6, 3 ] : [ 6, 2 ] : null
			Mutare Posibila: [ 6, 5 ] : [ 6, 4 ] : [ 6, 3 ] : [ 6, 2 ] : null
			Mutare Posibila: [ 5, 5 ] : [ 6, 4 ] : [ 6, 3 ] : [ 6, 2 ] : null
			Mutare Posibila: [ 7, 4 ] : [ 6, 3 ] : [ 6, 2 ] : null
			Mutare Posibila: [ 9, 1 ] : [ 8, 0 ] : null
			Mutare Posibila: [ 7, 3 ] : [ 6, 2 ] : null
			Mutare Posibila: [ 5, 3 ] : [ 6, 2 ] : null
			Mutare Posibila: [ 6, 1 ] : null
			Mutare Posibila: [ 7, 2 ] : null
			Mutare Posibila: [ 8, 2 ] : null
			Mutare Posibila: [ 8, 1 ] : null

		Nu am 2 mutari care ma duc acelasi punct. In caz ca am 2 care fac acest lucru, o selectez pe cea mai scurta.

----------------------------------------------
Alpha-Beta Pruning, varianta Negamax
----------------------------------------------

Am folosit algoritmul prezentat la laborator. Este izbitor de identic, diferenta consta doar in calcularea scorului si prin faptul ca am folosit o variabila de timp ca in cazul in care o ramura din arbore imi depaseste 50 milisecunde sa-mi sa nu mai mearga mai departe. Aceste "50ms" au fost gasite dupa cateva zeci de teste. Am incercat cu 1000, apoi cu 500 si tot asa pana am ajuns la 50.

Scorul dat de tabela_cu_scoruri prezentata mai sus este alterat un pic de:
	scor_din_tabel = scor_din_tabel - Math.abs(pozitie_veche.getY() - 4) - pozitie_veche.getX();
		unde pozitie_veche reprezinta pozitia la care se afla mingea in acest moment

Puteam sa calculez acest scor direct dintr-o formula, fara sa mai folosesc o matrice de scoruri (ma foloseam doar de X si Y), dar am plecat asa de la inceput si nu am mai modificat.

In cazul in care depasesc timpul de "50ms" cu o ramura din arbure, iar la mutarea care o evaluez este in favoarea mea, am sa returnez de 2 ori scorul aferent mutarii in acest moment:

	if ((curent - start > 50) && (play_as == PLAYER.PLAY_AS_N)) return scor_din_tabel * 2;

Daca mutarea care o analizat este a adversarului am sa returnez de 2 ori mai putin scorul

	if ((curent - start > 50) && (play_as == PLAYER.PLAY_AS_S)) return scor_din_tabel / 2;

Nu prea pot explic foarte clar de ce merge si de ce e foarte buna aceasta alegere. Aceasta functi de evaluare este rezultator a vreo cateva zeci de teste si am vazut ca asa mi se comporta cel mai bine.

	PLAYER.PLAY_AS_N - jucatorul care ataca spre nord
	PLAYER.PLAY_AS_S - jucatorul care ataca spre sud

---------------------------------------------
Euristici
---------------------------------------------

Pe langa setarea a celor 50ms mai filter si mutarile pe care vreau sa le analizez.
De exemplu, daca eu atac spre nord, nu am sa mai incerc sa evaluez cu alfabeta mutarile care stiu deja ca ma duc in sud. Le evaluez in cel mai rau caz pe cele care ma lasa pe aceeasi linie, dar nu mai jos de pozitia mea.

Numarul de mutari pe care le analizez este 4.
	private static final int MAXDEPTH = 3; // + inca 1 de din metoda "aflaMutare", acolo unde aflu scorul pentru fiecare mutare favorabila mie
Am incercat sa gandesc si cu doar 3 mutari in fata, dar luam bataie, iar cu 5 mutari in fata dupa prea mult pe anumite cauzuri. Dupa cateva teste am ajuns la concluzia ca "4" e de ajuns.

---------------------------------------------
Complexitate
---------------------------------------------

Complexitatea pentru minimax mi se pare cam greu de calculat, oricum este una prohibitiva.
	O(b^d) ~ O(4000) // pare mica
		- unde d la mine este 4
		- iar b este maxim 8

Parcurgerea in adancime in graf poate sa mai consume ceva, dar si aceasta mi se pare greu de calculat.