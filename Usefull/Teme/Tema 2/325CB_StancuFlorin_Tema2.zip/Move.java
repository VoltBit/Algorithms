/**
 * 
 * Metoda pentru o mutare.
 * 
 * @author Florin
 *
 */

public class Move {

	// x - pe verticala
	// y - pe orizontala
	private int x, y;
	
	// Mutarea din care mutarea curenta a fost deviata
	// null - daca nu a fost deviata
	private Move parinte;
	
	/**
	 * 
	 * Constructor pentru mutare.
	 * 
	 * @param x
	 * Coordonata verticala
	 * 
	 * @param y
	 * Coordonata orizontala
	 * 
	 */
	
	public Move(int x, int y) {
		
		this.x = x;
		this.y = y;
		
	}
	
	/**
	 * 
	 * Getter pentru coordonata verticala.
	 * 
	 * @return
	 * Coordonata verticala.
	 * 
	 */
	
	public int getX() { 
		return x;
	}
	
	/**
	 * 
	 * Getter pentru coordonata orizontala.
	 * 
	 * @return
	 * Coordonata orizontala.
	 * 
	 */
	
	public int getY(){
		return y;
	}
	
	/**
	 * 
	 * Metoda care-mi seteaza parintele mutarii curente.
	 * Adica mutarea din care a fost deviata.
	 * 
	 * @param m
	 * Mutarea din care a fost deviata.
	 * 
	 */
	
	public void addParinte(Move m) {
		this.parinte = m;
	}
	
	/**
	 * 
	 * Metoda care-mi returneaza mutarea din care a fost deviata.
	 * 
	 * @return
	 * Mutarea din care a fost deviata sau null
	 * 
	 */
	
	public Move getParinte() {
		return this.parinte;
	}
	
	@Override
	public String toString() {
		return "[ " + this.x + ", " + this.y + " ] : " + this.parinte; 
	}
	
	@Override
	public boolean equals(Object o) {
		
		if (o == null) return false;
		if (o == this) return true;
		if (!(o instanceof Move)) return false;
		
		Move m = (Move)o;
		if ((this.x == m.getX()) && (this.y == m.getY())) return true;
		
		return false;
		
	}
	
}
