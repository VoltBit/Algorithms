enum PLAYER {
		PLAY_AS_N, // jucatorul care ataca spre nord
		PLAY_AS_S // jucatorul care ataca spre sud
	};