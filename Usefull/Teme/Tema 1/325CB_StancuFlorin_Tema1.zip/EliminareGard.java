import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 * 
 * Clasa principala pentru prima problema.
 * 
 * @author Florin
 *
 */

public class EliminareGard {

	final static String fisier_intrare = "date.in";
	final static String fisier_iesire = "date.out";
	
	private int N, M, L;
	private ArrayList<Integer> stalpi;
	
	private int distanta_maxima;
	
	/**
	 * 
	 * Constructor pentru datele principale ale primei probleme.
	 * Aici se citesc datele de intrare.
	 * 
	 * @throws FileNotFoundException
	 * 
	 */
	
	public EliminareGard() throws FileNotFoundException { 
		
		// incepe citirea datelor
		
		File file = new File(fisier_intrare);
		Scanner scanner = new Scanner(file);
		
		this.N = scanner.nextInt();
		this.M = scanner.nextInt();
		this.L = scanner.nextInt();
		
		this.stalpi = new ArrayList<Integer>(N);
		
		while (scanner.hasNext())
			this.stalpi.add(scanner.nextInt());
		
		scanner.close();
		
	}
	
	/**
	 * 
	 * Metoda care-mi cauta distanta maxima admisa pentru eliminare.
	 * 
	 */
	
	public void CautareDistanta() {
		
		int lower = 0;
		int upper = L;
		
		int middle = 0;
		int eliminari;
		int ultimul_stalp_neeliminat;
		int distanta; // distanta dintre 2 stalpi
		int i;
		
		while (lower != upper - 1) {
			
			middle = lower + (upper - lower) / 2;
			ultimul_stalp_neeliminat = stalpi.get(0);
			eliminari = M;
			
			for (i = 1; i < N; i++) {
				
				if (eliminari < 0) break;
				
				distanta = stalpi.get(i) - ultimul_stalp_neeliminat;
				
				if (distanta < middle) eliminari--;
				else ultimul_stalp_neeliminat = stalpi.get(i);
				
			}
			
			// daca s-a parcurs tot vectorul, iar nr de eliminari este mai mare sau cel putin egal cu nr maxim de eliminari posibile
			// atunci caut in dreapta pentru o posibila distanta mai mare
			if ((i == N) && (eliminari >= 0)) lower = middle;
			
			// daca s-a depasit numarul de eliminari posibile
			// atunci caut in stanga pentru o distanta cert mai mica
			else if (eliminari == -1) upper = middle;
			
		}
		
		middle = lower + (upper - lower) / 2;
		
		this.distanta_maxima = middle;
		
	}
	
	/**
	 * 
	 * Metoda care-mi calculeaza distanta maxima posibila. Are ca efect lateral si eliminarea stalpilor.
	 * 
	 * @return
	 * Distanta maxima posibila.
	 * 
	 */
	
	public int EliminareStalpi() {
		
		int stalp_precedent = 0, stalp_curent, distanta, distanta_maxima_cautata = L;
		
		Iterator<Integer> it = stalpi.iterator();
		
		while(it.hasNext()) { // cat timp avem stalpi de parcurs
			
			stalp_curent = it.next();
			distanta = stalp_curent - stalp_precedent;
			
			if ((stalp_curent != 0) && (stalp_curent != L)) { // primul si ultimul stalp nu sunt luati in calcul
			
				if (distanta < distanta_maxima) {
					it.remove();
				} else {
					stalp_precedent = stalp_curent;
					if (distanta < distanta_maxima_cautata) distanta_maxima_cautata = distanta;
				}
				
			}
			
		}
		
		return distanta_maxima_cautata;
		
	}
	
	/**
	 * 
	 * Metoda care-mi afiseaza rezultatele.
	 * 
	 * @throws IOException 
	 * 
	 */
	
	public void Afisare() throws IOException {
		
		File file = new File(fisier_iesire);
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		
		int distanta_maxima_cautata = EliminareStalpi();

		writer.write(distanta_maxima_cautata + "\n");
		writer.write(stalpi.size() + "\n");
		
		for (Integer stalp : stalpi)
			writer.write(stalp + "\n");
		
		writer.close();
		
	}
	
	/**
	 * 
	 * Metoda Main
	 * 
	 * @param args
	 * Lista de argumente.
	 * 
	 * @throws IOException 
	 * 
	 */
	
	public static void main(String[] args) throws IOException {

		EliminareGard p1 = new EliminareGard();
		p1.CautareDistanta();
		
		p1.Afisare();
		
	}

}
