/**
 * 
 * Clasa pozitie pentru elementele din matricea starilor.
 * 
 * @author Florin
 *
 */

public class Pozitie {

	int i, j;
	
	/**
	 * 
	 * Constructor principal pentru pozitie.
	 * 
	 * @param i
	 * Pozitia pe verticala.
	 * 
	 * @param j
	 * Pozitia pe orizontala.
	 * 
	 */
	
	public Pozitie(int i, int j) {
		
		this.i = i;
		this.j = j;
		
	}
	
	@Override
	public String toString() {
		return "(" + i + ", " + j + ")";
	}

}
