/**
 * 
 * Clasa pentru un interval.
 * 
 * @author Florin
 *
 */
public class Interval {
	
	int inceput, sfarsit;
	
	/**
	 * 
	 * Construcutor pentru interval.
	 * 
	 * @param sfarsit
	 * La inceput sfarsitul = inceputul, urmand ca ulterior sa modifici inceputul intervalului.
	 * 
	 */
	
	public Interval(int sfarsit) {
		
		this.inceput = sfarsit;
		this.sfarsit = sfarsit;
		
	}
	
	/**
	 * 
	 * Metoda care-mi mareste intervalul.
	 * 
	 */
	
	public void marire() {
		this.inceput--;
	}
	
	@Override
	public boolean equals(Object  i) {

		if (i == null) return false;
		if (i == this) return true;
		if (!(i instanceof Interval)) return false;
		
		Interval i_cast = (Interval)i;
		
		if ((i_cast.inceput == this.inceput) && (i_cast.sfarsit == this.sfarsit)) return true;
		
		return false;
		
	}
	
	@Override
	public String toString() {
		return "[ " + inceput + ", " + sfarsit + " ]";
	}

}
