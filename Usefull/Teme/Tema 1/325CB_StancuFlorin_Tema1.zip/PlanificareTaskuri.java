import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * 
 * Clasa principala pentru ce-a de a doua problema.
 * 
 * @author Florin
 *
 */

public class PlanificareTaskuri {

	final static String fisier_intrare = "date.in";
	final static String fisier_iesire = "date.out";
	
	private int N, T;
	private ArrayList<Integer> castiguri;
	
	private int[][] matrice; // matricea de stari
	private int castig_maxim;
	
	private HashMap<String, Pozitie> pozitii = new HashMap<String, Pozitie>(); // pozitiile potentialelor castiguri din matrice
	private LinkedList<Interval> intervale = new LinkedList<Interval>();
	
	/**
	 * 
	 * Constructor pentru datele principale ale celei de a doua problema.
	 * Aici se citesc datele de intrare.
	 * 
	 * @throws IOException 
	 * 
	 */
	
	public PlanificareTaskuri() throws IOException {
		
		// incepe citirea datelor
		
		BufferedReader br = new BufferedReader(new FileReader(fisier_intrare));
		
		String line = br.readLine();
		String[] nrs = line.split(" ");
		
		this.N = Integer.parseInt(nrs[0]);
		this.T = Integer.parseInt(nrs[1]);
		
		this.castiguri = new ArrayList<Integer>(N);
		this.matrice = new int[T][N];
		
		while ((line = br.readLine()) != null)
			this.castiguri.add(Integer.parseInt(line));
		
		br.close();
		
	}
	
	/**
	 * 
	 * Metoda care-mi afiseaza rezultatele.
	 * 
	 * @throws IOException
	 * 
	 */
	
	public void Afisare() throws IOException {
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(fisier_iesire));

		writer.write(castig_maxim + "\n");
		
		writer.write(intervale.size() + "\n");
		
		for (Interval i : intervale)
			writer.write(i.inceput + " " + i.sfarsit + "\n");
		
		writer.close();
		/*
		for (int i = 0; i < T; i++) {
			for (int j = 0; j < N; j++)
				System.out.print(matrice[i][j] + " ");
			System.out.println();
		}
		*/
	}
	
	/**
	 * 
	 * Metoda care-mi construieste matricea de stari.
	 * Tot aici imi calculez si castigul maxim.
	 * 
	 */
	
	public void ConstruireMatrice() {
		
		int maxim = 0; // variabila in care imi calculez maximul pentru fiecare element A[i,j] din matrice
		// variabila in care-mi retin un maxim anterior, pentru a nu mai recalcula maximul de la j la 0 la fiecare pas
		int maxim_linie_superioara; 
		
		// prima linie din matrice contine 0, pentru ca daca am alege T = 1 fiecare problema ar avea costul maxim 0
		for (int j = 1; j < N; j++) {
			matrice[1][j] = castiguri.get(j); // cea de a doua linie contine chiar elementul de pe pozitia j
			
			// salvam pozitia primei aparitii a fiecarui numar pe prima linie
			// ma ajuta la reconstituirea solutiei
			if (!pozitii.containsKey(matrice[1][j] + "_1")) pozitii.put(matrice[1][j] + "_1", new Pozitie(1, j));
			
			// actualizam castigul maxim daca este cazul
			if (matrice[1][j] > castig_maxim) castig_maxim = matrice[1][j];
		}
		
		// recurenta incepe pentru T >= 2
		for (int i = 2; i < T; i++) {
			
			maxim_linie_superioara = 0;
			
			for (int j = i; j < N - T + i + 1; j++) {
				
				maxim = 0; // aici o sa avem maximul pentru elemenul (i,j) din matrice
				
				// calculam maximul de pe linia (i - 1) dintre primele (j - 1) elemente
				if (maxim_linie_superioara < matrice[i - 1][j - 1]) maxim_linie_superioara = matrice[i - 1][j - 1];
				
				if (maxim < maxim_linie_superioara) maxim = maxim_linie_superioara;
				
				if (maxim < matrice[i - 1][j - 1] + castiguri.get(j)) maxim = matrice[i - 1][j - 1] + castiguri.get(j);
				
				matrice[i][j] = maxim;
				
				// aceeasi semnificatie ca cea de la (T = 1)
				if (!pozitii.containsKey(maxim + "_" + i)) pozitii.put(maxim + "_" + i, new Pozitie(i, j));
				
				// actualizam castigu maxim doar daca ne aflam la ultima problema
				if ((i == T - 1) && (maxim > castig_maxim)) castig_maxim = maxim;
				
			}
			
		}
		
	}
	
	/**
	 * 
	 * Metoda care-mi afla intervalele pe baza castigul maxim si pozitiilor din matrice.
	 * 
	 */
	
	public void ReconstituireSolutie() {
		
		Interval interval_nou; // aici o sa salvez un interval cand o sa-l gasesc
		
		// plec de la maximul gasit si o sa scad pe parcurs ce construiesc intervale
		int maxim = castig_maxim;
		
		// aflu pozitia castigului maxim
		Pozitie poz = pozitii.get(maxim + "_" + (T - 1));
		
		// si incepand de acolo creez un interval
		interval_nou = new Interval(poz.j + 1);
		
		
		while (true) {
			
			// cand ajung pe prima linie ma opresc (adica la T = 1)
			if (matrice[poz.i - 1][poz.j - 1] == 0)
				break;
			
			// daca elementul de la (T = i - 1) cu (j - 1) elemente continua intervalul
			
			if (matrice[poz.i - 1][poz.j - 1] == maxim - castiguri.get(poz.j)) {
				
				interval_nou.marire(); // il adaug intervalului nou cret
				maxim = matrice[poz.i - 1][poz.j - 1]; // scad maximul gasit
				
				// si ma pozitionez pe noul maxim
				poz.i = poz.i - 1;
				poz.j = poz.j - 1;
				
			} else { // aici e cazul in care trebuie sa creez un nou interval
				
				intervale.add(interval_nou); // adaug intervalul precedent la lista cu intervale

				// si incep sa creez altul
				poz = pozitii.get(maxim + "_" + (poz.i - 1)); // aflu pozitia noului maxim
				interval_nou = new Interval(poz.j + 1); // si incep alt interval
				
			}
			
		}
		
		// cand o sa-mi iasa din while o sa inchid intervalul
		interval_nou.marire();
		intervale.add(interval_nou); // si o sa-l bag in multimea intervalelor
		
	}
	
	/**
	 * 
	 * Metoda Main.
	 * 
	 * @param args
	 * Lista de argumente.
	 * 
	 * @throws IOException 
	 * 
	 */
	
	public static void main(String[] args) throws IOException {
		
		PlanificareTaskuri p2 = new PlanificareTaskuri();
		
		p2.ConstruireMatrice();
		
		p2.ReconstituireSolutie();
		
		p2.Afisare();
		
	}

}
