import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;


public class Bonus {

	final static String fisier_intrare = "date.in";
	final static String fisier_iesire = "date.out";
	
	private int N, T;
	private ArrayList<Integer> castiguri;
	private int castig_maxim;
	private int indice_matrice_buna; // indicele de la care incep cele N coloane din matricea de N + T coloane
	
	private int[][] matrice; // matricea de stari
	private HashMap<String, Pozitie> pozitii = new HashMap<String, Pozitie>(); // pozitiile potentialelor castiguri din matrice
	private LinkedList<Interval> intervale = new LinkedList<Interval>();
	
	/**
	 * 
	 * Constructor pentru datele principale ale celei de a doua problema.
	 * Aici se citesc datele de intrare.
	 * 
	 * @throws FileNotFoundException
	 * 
	 */
	
	public Bonus() throws FileNotFoundException {
		
		// incepe citirea datelor
		
		File file = new File(fisier_intrare);
		Scanner scanner = new Scanner(file);
		
		this.N = scanner.nextInt();
		this.T = scanner.nextInt();
		
		this.matrice = new int[T][N];
		this.castiguri = new ArrayList<Integer>(N + T);
		
		while (scanner.hasNext())
			this.castiguri.add(scanner.nextInt());
		
		scanner.close();
		
		// primele T castiguri le copiez la final
		for (int i = 0; i < T; i++) {
			this.castiguri.add(castiguri.get(i));
		}
		
	}
	
	/**
	 * 
	 * Metoda care-mi afiseaza rezultatele.
	 * 
	 * @throws IOException
	 * 
	 */
	
	public void Afisare() throws IOException {
		
		File file = new File(fisier_iesire);
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));

		writer.write(castig_maxim + "\n");
		
		writer.write(intervale.size() + "\n");
		
		for (Interval i : intervale)
			if (i.sfarsit + indice_matrice_buna > N)
				writer.write((i.inceput + indice_matrice_buna) + " " + (i.sfarsit + indice_matrice_buna - N) + "\n");
			else
				writer.write((i.inceput + indice_matrice_buna) + " " + (i.sfarsit + indice_matrice_buna) + "\n");
		
		writer.close();
		
	}
	
	/**
	 * 
	 * Metoda care-mi genereaza ultima linie din matricea care incepe de la pozitia data ca parametru.
	 * Imi calculeaza si maximul.
	 * 
	 * @param inceput
	 * Indicele de la care incepe "calcularea" matricii
	 * 
	 * @return
	 * Ultima linie din matrice si maximul.
	 * 
	 */
	
	public int[][] GenerareVector(int inceput) { 
		
		// mai multe detalii despre algoritmul acesta in readme
		
		int[][] vectori = new int[3][N - T + 2];
		int maxim_linie_superioara = Integer.MIN_VALUE;
		
		for (int i = 0; i < N - T + 2; i++)
			vectori[0][i] = castiguri.get(i + 1 + inceput);
		
		for (int i = 2; i < T; i++) {
			
			maxim_linie_superioara = Integer.MIN_VALUE;
			
			for (int j = 0; j < N - T + 2; j++) {
				
				if (maxim_linie_superioara < vectori[0][j])
					maxim_linie_superioara = vectori[0][j];
				
				if (maxim_linie_superioara < vectori[0][j] + castiguri.get(i + j + inceput))
					vectori[1][j] = vectori[0][j] + castiguri.get(i + j + inceput);
				else
					vectori[1][j] = maxim_linie_superioara;
				
				if ((i == T - 1) && (j != N - T + 2) && (vectori[2][0] < vectori[1][j])) vectori[2][0] = vectori[1][j];
				
			}
			
			vectori[2][1] = vectori[0][N - T + 1];
			
			System.arraycopy(vectori[1], 0, vectori[0], 0, N - T + 2);
			
		}

		return vectori;
		
	}
	
	/**
	 * 
	 * Metoda care-mi calculeaza castigul maxim si indicele de la care incepe matricea in care se afla acest castig.
	 * 
	 */
	
	public void CalculareMaxim() {
		
		int maxim = Integer.MIN_VALUE;
		int[][] vectori;
		int i = 0;
		
		for (i = 0; i < T; i++) {
			
			vectori = GenerareVector(i);
			
			if (vectori[2][0] > maxim) maxim = vectori[2][0];
			else if (vectori[2][1] + castiguri.get(i + N) != vectori[1][N - T + 1]) break;
			
		}
		
		this.indice_matrice_buna = i - 1;
		if (i - 1 < 0) this.indice_matrice_buna = 0;
		
		this.castig_maxim = maxim;
		
	}
	
	
	/**
	 * 
	 * Metoda care-mi cosntruieste matricea, cunoscand initial de unde incepe.
	 * Are T linii si N coloane.
	 * 
	 */
	
	public void ConstruireMatrice() {
		
		int maxim = 0; // variabila in care imi calculez maximul pentru fiecare element A[i,j] din matrice
		// variabila in care-mi retin un maxim anterior, pentru a nu mai recalcula maximul de la j la 0 la fiecare pas
		int maxim_linie_superioara; 
		
		if (!pozitii.containsKey(castig_maxim + "_" + (T - 1))) 
			this.indice_matrice_buna = this.indice_matrice_buna + 1;
		
		// prima linie din matrice contine 0, pentru ca daca am alege T = 1 fiecare problema ar avea costul maxim 0
		for (int j = 1; j < N; j++) {

			matrice[1][j] = castiguri.get(j + indice_matrice_buna); // cea de a doua linie contine chiar elementul de pe pozitia j
			
			// salvam pozitia primei aparitii a fiecarui numar pe prima linie
			// ma ajuta la reconstituirea solutiei
			if (!pozitii.containsKey(matrice[1][j] + "_1")) pozitii.put(matrice[1][j] + "_1", new Pozitie(1, j));
			
		}
		
		// recurenta incepe pentru T >= 2
		for (int i = 2; i < T; i++) {
			
			maxim_linie_superioara = 0;
			
			for (int j = i; j < N - T + i + 1; j++) {
				
				maxim = 0; // aici o sa avem maximul pentru elemenul (i,j) din matrice
				
				// calculam maximul de pe linia (i - 1) dintre primele (j - 1) elemente
				if (maxim_linie_superioara < matrice[i - 1][j - 1]) maxim_linie_superioara = matrice[i - 1][j - 1];
				
				if (maxim < maxim_linie_superioara) maxim = maxim_linie_superioara;
				
				if (maxim < matrice[i - 1][j - 1] + castiguri.get(j + indice_matrice_buna)) 
					maxim = matrice[i - 1][j - 1] + castiguri.get(j + indice_matrice_buna);
				
				matrice[i][j] = maxim;
				
				// aceeasi semnificatie ca cea de la (T = 1)
				if (!pozitii.containsKey(maxim + "_" + i)) pozitii.put(maxim + "_" + i, new Pozitie(i, j));
				
			}
			
		}
		
	}
	
	/**
	 * 
	 * Metoda care-mi reconstruieste solutia.
	 * 
	 */
	
	public void ReconstituireSolutie() {
		
		Interval interval_nou; // aici o sa salvez un interval cand o sa-l gasesc
		
		// plec de la maximul gasit si o sa scad pe parcurs ce construiesc intervale
		int maxim = castig_maxim;
		
		// aflu pozitia castigului maxim
		Pozitie poz = pozitii.get(maxim + "_" + (T - 1));
		
		// si incepand de acolo creez un interval
		interval_nou = new Interval(poz.j + 1);
		
		
		while (true) {
			
			// cand ajung pe prima linie ma opresc (adica la T = 1)
			if (matrice[poz.i - 1][poz.j - 1] == 0)
				break;
			
			// daca elementul de la (T = i - 1) cu (j - 1) elemente continua intervalul
			
			if (matrice[poz.i - 1][poz.j - 1] == maxim - castiguri.get(poz.j + indice_matrice_buna)) {
				
				interval_nou.marire(); // il adaug intervalului nou cret
				maxim = matrice[poz.i - 1][poz.j - 1]; // scad maximul gasit
				
				// si ma pozitionez pe noul maxim
				poz.i = poz.i - 1;
				poz.j = poz.j - 1;
				
			} else { // aici e cazul in care trebuie sa creez un nou interval
				
				intervale.add(interval_nou); // adaug intervalul precedent la lista cu intervale

				// si incep sa creez altul
				poz = pozitii.get(maxim + "_" + (poz.i - 1)); // aflu pozitia noului maxim
				interval_nou = new Interval(poz.j + 1); // si incep alt interval
				
			}
			
		}
		
		// cand o sa-mi iasa din while o sa inchid intervalul
		interval_nou.marire();
		intervale.add(interval_nou); // si o sa-l bag in multimea intervalelor
		
	}
	
	/**
	 * 
	 * Metoda Main.
	 * 
	 * @param args
	 * Lista de argumente.
	 * 
	 * @throws IOException 
	 * 
	 */
	
	public static void main(String[] args) throws IOException {
		
		Bonus pb = new Bonus();
		
		pb.CalculareMaxim();
		
		pb.ConstruireMatrice();
		
		pb.ReconstituireSolutie();
		
		pb.Afisare();
		
		
	}

}
