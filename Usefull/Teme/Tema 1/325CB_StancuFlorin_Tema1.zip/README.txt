Prima Problema - Eliminare Gard
Fisiere: EliminareGard.java

Am impartit problema in 2 parti:
	- cautarea distantei optime
	- eliminare stalpilor

Cautarea distantei optime este o cautare binara intre 0 si L. Prima data se pleaca cu L/2 si se verifica cati stalpi pot sa elimin cu distanta dintre ei mai mica ca aceasta. Daca acest numar il depaseste pe M se incearca cu o distanta intre 0 si L/2 sau intre L/2 si L, depinzand de caz. Cand am aflat aceasta distanta optima se trece la eliminarea stalpilor.
Complexitatea este O(N * logN).

Eliminarea stalpilor se face prin parcurgerea stalpilor de la 0 la N si se elimina stalpii care au o distanta intre ei mai mica decat cea alfat la pasul anterior.
Complexitatea este O(N).

Complexitatea totala este O(N * logN).

--------------------------------------------------------

A Doua Problema - Planificare Taskuri
Fisiere: PlanificareTaskuri.java, Interval.java, Pozitie.java

Am impartit problema in 2 parti:
	- construirea unei matrici de stari si flarea castigului maxim
	- reconstituirea solutiei (determinarea intervalelor)

Cunoasteam ca aveam N castiguri dintre care trebuie sa alegem doar T pentru a forma un numar de "secvente", castigul total fiind maxim. Rezolvarea problemi pricipale se face prin rezolvarea unor subprobleme mai mici. Starile pentru fiecare subproblema sunt notate in matricea starilor. Aceasta matrice este de forma A[T][N], astfel elemenul de pe pozitia A[i][j] reprezinta solutia pentru problema in care avem "j" obiecte (in cazul nostru castiguri) dintre care trebuind sa alegem "i" pentru a ne da un castig maxim.

	3	9	1	1	7	// aici sunt reprezentate castigurile
----------------------------------------------
	1	2	3	4	5	// acestia sunt indicii castigurilor
______________________________________________
1	0	0	0	0	0	
______________________________________________
2		9	1	1	7
______________________________________________
3			10	9	9
______________________________________________
4				11	16


Pentru a mai economisi timp, nu am mai calculat partea superioara matricii pentru ca oricum nu aveam nevoie de ea. In algoritmul meu, matricea arata ceva de genu.

	3	9	1	1	7	// aici sunt reprezentate castigurile
----------------------------------------------
	1	2	3	4	5	// acestia sunt indicii castigurilor
______________________________________________
1	0	0				
______________________________________________
2		9	1		
______________________________________________
3			10	9	
______________________________________________
4				11	16


Matricea de mai sus reprezinta matricea starilor pentru exemplul din tema. Se observa ca pentru (T = 1) avem 0 pe toata linia deoarece 0 este castigul maxim daca alegem doar un slot. Pentru (T = 2) este chiar castigul de pe pozitia "j" pentru ca acela este castigul maxim daca am alege 2 sloturi cu un interval care sa se termina chiar in elemenul de pe pozitia "j". Completarea pe linii incepe de la elemenul A[i,i] pana la elementul A[i,N].

Completarea matricii pentru (T > 2) se face folosind urmatoarea formula: A[i][j] = maxim { A[i-1][i-1], A[i-1][i], A[i-1][i+1] ... A[i-1][j-1], A[i-1][j-1] + castig[j]}
Complexitatea este O(N * T)

Pentru reconstituirea solutiei am salvat intr-un heap la fiecare pas T (adica pentru fiecare linie), prima aparitie a fiecarul numar. Cheia folosita este un string de forma "numar_linie".
Dupa ce am aflat maximul, aflu pozitia folosind cheia "maxim_T", pentru exemplu de mai sus "16_4" o sa-mi returneze [4][5]. Stiu sigur ca aici mi se termina un interval si urc pe diagonala ca sa vad cat tine intervalul. Din exempul de mai sus, din 16 ma duc in 9 ([3][4]) pentru ca 9 + castig[5] = 16.
Se observa ca elemenul de pe pozitia [2][3] nu mai respecta regula de mai sus, deci intervalul s-a terminat, iar eu am ramas cu un castig maxim de 9 format din T = 2 sloturi. Apoi o sa aflu pozitia noului maxim din heap folosind cheia "9_2", care-mi va da pozitia [2][2], de aici incepand un alt interval si tot asa.
Complexitatea este O(T).

Pentru valori mai mari, se pare ca acest heap nu a fost o alegere chiar tocmai potrivita, deoarece se misca un pic mai greoi pe cautare, dar totusi cred ca scot o complexitate totala de O(N * T).

--------------------------------------------------------

Problema Bonus
Fisiere: Bonus.java, Interval.java, Pozitie.java

Aceasta problema seamana cu problema precedenta doar ca de aceasta data am mai extins matricea de stari cu inca T coloane. Ultimele T elemente din vectorul de castiguri reprezinta chiar primele T elemente din vector (sunt puse o data la inceput si o data la final).

	3	9	1	1	7	3	9	1	1
--------------------------------------------------------------------------------
	1	2	3	4	5	6	7	8	9
________________________________________________________________________________
1	0	0	0	0	0	0	0	0	0		
________________________________________________________________________________
2		9	1	1	7	3	9	1	1	
________________________________________________________________________________
3			10	9	9	x3	y3
________________________________________________________________________________
4				11	16	x4	y4
________________________________________________________________________________

Aici mi-am pus problema in a alege o "submatrice" de dimensiune [T][N] din matricea "mama" de dimensiune [T][N+T] astfel incat sa-mi dea un castig maxim. Am calculat castigul maxim pentru matricea formata din primele N coloane, apoi m-am deplasat la dreapta cu o coloana si am renuntat la coloana cu indicele 0, apoi m-am deplasat cu 2 coloane si tot asa pana am gasit matricea cu castigul cel mai mare. De fapt, m-am deplasat pana cand am gasit o continuitate in intervalul circular.

Pentru aceasta problema am modificat un pic algoritmul de determinare a matricii de stari. Am folosit doar 2 vectori (in cod sunt vazuti ca o matrice de 2 linii, iar pe a 3-a linie urmand sa salvez maximul) pentru a mai micsora un pic complexitatea spatiala.
De exemplu: pentru determinarea liniei "i" din matrice avem nevoie doar de linia "i-1", pentru a determina "i-1" avem nevoie doar de "i-2" si tot asa. Acesti vectori au dimensiunea "N - T + 1", cum se poate observa si in matricea de la problema 2.

Pentru a verifica daca am interval in continuitate (circulara) am mai exting acesti 2 vectori cu inca un element pentru a salva si elementul necesar verificarii pentru pasul urmator.

Dupa ce am aflat de la ce pozitie incepe o matrice de N coloane, o generez folosind un algoritmul de la problema 2, iar apoi folosesc aceeasi reconstituire a solutiei.
Complexitatea pentru generarea matricii si reconstituire ramana tot O(N * T), dar cum in acest caz matricea mi se genereaza de un "k" (numar intreg mai mic decat T) numar ori complexistatea este O(k * N * T).

In cazul cel mai nefavorabil avem O(N * T^2).