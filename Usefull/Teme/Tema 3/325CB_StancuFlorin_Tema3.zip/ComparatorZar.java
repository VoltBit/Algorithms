import java.util.Comparator;

/**
 * 
 * Comparator pentru 2 zaruri.
 * 
 * @author Stancu Florin
 * 325CB
 * 
 */

public class ComparatorZar implements Comparator<Zar> {
	
	@Override
	public int compare(Zar z1, Zar z2) {

		return z1.getCost() - z2.getCost();
		
	}
	
}
