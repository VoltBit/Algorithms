------------------------------------------------------
Problema 1 - Fotbal
------------------------------------------------------
Fisiere: Fotbal.java, Graph.java

Fisierul "Graph.java" este identic (in totalitate) cu cel din scheletul de cod de la laboratorul 10. Am vazut pe forum ca avem voie sa facem asta. Pe langa acest lucru, in fisierul "Fotbal.java" mai exista 3 metode importate in totalitate din laboratorul 10 (bfs, saturate_path, maxFlow). TODO-urile din din ultimele 2 functii au fost rezolvate de mine in cadrul laboratorului, iar codul nu l-am mai dat la nimeni. De asemenea, codul laboratorului 10 l-am uploadat si pe cs.curs pentru ca s-a cerut acest lucru.
--------------------------

Prima data in rezolvarea problemei avem nevoie de punctajele curente pentru fiecare echipa. Le-am salvat intr-un vector, iar puncte_stranse[i] reprezinta punctele stranse de echipa i in cadrul meciurilor jucate.
Am mai folosit si o matrice de dimensiunea N * N unde in partide_ramase_de_jucat[i][j] salvat numarul de meciuri pe care echipa i le mai are de jucat impotriva echipei j.

Pana a incepe construirea grafului pentru care calculam fluxul maxim, trebuie sa pregatim capacitatile muchiilor corespunzatoare.
Astfel, daca dorim sa vedem daca o echipa X poate castiga campionatul, calculam in primul si primul rand numarul maxim de puncte pe care aceasta echipa il poate avea la finalul campionatului.
Dupa acest lucru
 am calculat numarul de puncte pe care echipele adverse nu trebuie sa le depaseasca pentru ca echipa X sa castige campionatul.

	puncte_necesare[i] = maxim_puncte - puncte_stranse[i];
	
	- unde maxim_puncte reprezinta maximul de puncte pe care echipa X il poate avea la finalul campionatului
	- iar, puncte_necesare[i] reprezinta punctele pe care echipa i nu trebuie sa le depaseasca in urma disputarii si meciurilor nejucate pentru ca echipa X sa castige campionatul.

!! Daca puncte_necesare[i] < 0 rezulta clar ca echipa i are deja mai multe puncte decat poate obtive vreodata echipa X, deci aceasta din urma nu mai poate castiga campionatul.

Apoi, pentru a construii graful avem nevoie de urmatoarele noduri:


	- fie "dimensiune_subset" numarul de echipe adverse
	- nodurile din intervalul [1, dimensiune_subset] reprezinta echipele adverse
	- iar, nodurile din intervalul [
dimensiune_subset + 1, dimensiune_subset * (dimensiune_subset - 1) / 2] reprezinta meciurile dintre echipele adverse
	- 0 este nodul sursa
	- (dimensiune_subset * (dimensiune_subset - 1) / 2 + 1) este nodul destinatie.

!! Un nod din intervalul [
dimensiune_subset + 1, dimensiune_subset * (dimensiune_subset - 1) / 2] reprezinta o partida dintre 2 echipe adverse - sa le spuneam i si j.

Atribuirea capacitatilor in graf:

	- de la nodul 0 catre un nod reprezentand un meci intre echipele i si j (echia adverse echipei X) am pus o capacitate egala cu numarul de partide ramase de jucat intre echipele i si j.
	- de la acest nod catre nodul i si catre nodul j am pus aceeasi capacitate
	- de la un nod reprezentand o echipa catre nodul destinatie, am pus capacitatea egala cu numarul de puncte pe care echipa respectiva nu trebuie sa le depaseasca ca echipa X sa poata castiga campionatul.

In acest timp am calculat si numarul de meciuri care vor fi jucate intre echipele adverse.

Daca fluxul maxim de la nodul sursa catre nodul destinatie era egal cu numarul de meciuri care urmau sa fie jucate intre echipele adverse, atunci echipa X are sanse sa castige.
Mai mult, daca media artimetica a punctajelor finale ale adeversarilor este mai mare sau cel putin egala cu punctajul maxim final al echipei X, echipa X este eliminata garantat.

Complexitate
----------------------
Complexitate pentru construirea grafului este O((N - 1) * (N - 2) / 2)
Numarul de subseturi de dimensiune 2 a unui set de dimensiune N este combinari de N luate cate 2.
Deci, complexitatea pentru constuirea grafului intra in O(N ^ 2).

Complexitatea pentru BFS este O(|E|+|V|), unde
	- |V| = N - 1
	- |E| = 3 * (combinari de (N - 1) luate cate 2 + (N - 1)
Deci, per total tot un O(N^2).

Complexitatea totala vine in jur de O(Q * N^2)

Referinte
-------------------------

Am gasit o prezentare foarte buna pentru o problema asemanatoare, iar in rezolvarea mea am cam urmat unii pasi de acolo.
http://www.ohio.edu/people/melkonia/math3050/slides/baseball.ppt

------------------------------------------------------
Problema 2 - Zar
------------------------------------------------------

Fisiere: MainZar.java Zar.java Pozitie.java ComparatorZar.java Enums.java

Noi avem de calculat drumul minim de la o sursa la o destinatie. Dar diferenta dintre aceasta problema si una clasica este ca aici se poate ca pe o pozitie din matrice un zar (vazut in spatiu) sa vina sub mai multe forme (poate sa fie un pic rasucit, rasturnat s.a.m.d).

In rezolvarea problemei am folosit un algoritm Dijkstra, dar l-am modificat un pic fata de versiunea care am folosit-o la laborator.
Astfel, daca algoritmul Dijkstra (cel prezentat la laborator) era de tip Greedy si lua optimul local (optim reprezentat de costul drumului de la sursa pana la nodul la care ne afla) si nu se mai gandea ca o alegere un pic mai proasta la momentul actual, poate sa ne dea un drum mai mic pentru final.

El gandea ceva de forma:
	- daca am ajuns pe o anumita pozitie cu un cost mai mic decat am ajuns anterior in aceasta pozitie, inseamna ca am gasit un drum mai scrut, deci actualizez datele

Algoritmul meu un pic modificat gandeste cam asa:
	- daca am ajuns pe o anumita pozitie, dar costul este un pic mai mare decat drumul pe care am ajuns pe aceasta pozitie anterior, am sa salvez si aceste date intr-o variabila si am sa incerc sa gasesc un drum mai scurt si cu aceste date

Costurile si pozitiile vizitate le-am reprezentat sub forma unor matrici tridimensionale, lucrez cumva pe mai multe "universuri" (daca se poate spune asa).
La final drumul cel mai scurt se va gasi chiar in primul "univers", in costuri_pozitii[destinatie.getX()][destinatie.getY()][0], iar
	costuri_pozitii[destinatie.getX()][destinatie.getY()][1]
	costuri_pozitii[destinatie.getX()][destinatie.getY()][2]
	costuri_pozitii[destinatie.getX()][destinatie.getY()][3]
	costuri_pozitii[destinatie.getX()][destinatie.getY()][4]
	s.a.m.d.

	au costuri pentru alte drumuri (costuri un pic mai mari).

Metoda in care am implementat acest algorit se numeste "explorare" si se gaseste in clasa MainZar.

Pentru fiecare zar eu salvez reprezentarea acestuia in spatiu, imi salvez valorile fetei de sus, de jos, din stanga s.a.m.d.
Cum am spus si mai sus, un zar poate ajunge intr-o pozitie din matrice sub mai multe forme (ceea ce este acceptat), dar nu las niciodata un zar sa ajunga in aceeasi pozitie cu aceeasi forma. Pentru a diferentia aceste zaruri in spatiu folosesc o functie de hashcode (functie care imi returneaza un integer unic - se gaseste in clasa Zar si se numeste codificare).

Complexitate
---------------------------------------

Complexitatea pentru un Dijkstra normal este O(|V|^2 + |E|)
unde:
	|V| - este dat de N * M * 24 // pentru ca un zar poate ajunge in 24 de feluri intr-o pozitie din matrice
	|E| - fiecare nod are maxim 3 vecini (pentru ca nu am mai luat si muchie catre parinte). Deci vine 3 * |V|
rezulta un O(|V|^2)
dar pentru ca lucrez pe matrici tridimensiunale o sa rezulte un O(U * |V|^2)
unde:
	U - numarul de "universuri"