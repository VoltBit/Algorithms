import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 * 
 * Clasa principala pentru a doua problema.
 * 
 * @author Stancu Florin
 * 325CB
 *
 */

public class MainZar {

	private int N;
	private int M;
	private final static int U = 8;	// numarul de "universuri" pe care calculeaza distanta
	private final static int INF = 999999;
	private int[] valoare_fata;
	private Pozitie sursa;
	private Pozitie destinatie;
	private int[][][] costuri_pozitii;
	private int[][][] pozitii_vizitate;
	
	/**
	 * 
	 * Costructorul principal.
	 * 
	 * @param N
	 * Numarul de linii ale matricii.
	 * 
	 * @param M
	 * Numarul de coloane ale matricii.
	 * 
	 * @param valoare_fata
	 * Valorile fetelor unui zar.
	 * 
	 * @param sursa
	 * Pozitia sursei.
	 * 
	 * @param destinatie
	 * Pozitia destinatiei.
	 * 
	 */
	
	public MainZar(int N, int M, int[] valoare_fata, Pozitie sursa, Pozitie destinatie) {
		
		this.N = N;
		this.M = M;
		this.valoare_fata = valoare_fata;
		this.sursa = sursa;
		this.destinatie = destinatie;
		this.pozitii_vizitate = new int[N][M][U];
		this.costuri_pozitii = new int[N][M][U];
		
		// inializam costurile pe toate "universurile"
		
		for (int i = 0; i < N; i++)
			for (int j = 0; j < M; j++)
				for (int k = 0; k < U; k++)
					costuri_pozitii[i][j][k] = INF;
		
	}
	
	/**
	 * 
	 * Metoda care-mi verifica daca o stare a unui zar (un zar vazut in spatiu)
	 * a mai trecut printr-o pozitie din matrice.
	 * 
	 * @param vector
	 * Vectorul care contine stari ale unui zar de pe o anumita pozitie.
	 * 
	 * De exemplu:
	 * 	pozitii_vizitate[5][3] -> un vector cu starile zarurilor care au mai trecut prin
	 * 	pozitia [5, 3]
	 * 
	 * @param numar
	 * Codificarea zarului care vrem sa-l cautam.
	 * 
	 * @return
	 * In cazul in care exista returneaza -1
	 * 	altfel returneaza o pozitie pe care sa adaugam starea zarului in vector
	 * 
	 */
	
	public int contains(int[] vector_stari_zar, int stare_zar) {
		
		for (int i = 0; i < U; i++)
			if (vector_stari_zar[i] == stare_zar)
				return -1;
			else if (vector_stari_zar[i] == 0)
				return i;
		
		return -1;
		
	}
	
	/**
	 * 
	 * Metoda care-mi exploreaza matricea si gaseste calea cea mai scurta
	 * de la sursa la destinatie.
	 * 
	 * @throws IOException
	 * 
	 */
	
	public void explorare() throws IOException {
		
		Zar zar_sursa = new Zar(sursa, this.valoare_fata);
		
		Comparator<Zar> comparatorZAR = new ComparatorZar();
		PriorityQueue<Zar> coada = new PriorityQueue<Zar>(1, comparatorZAR);
		
	    this.costuri_pozitii[sursa.getX()][sursa.getY()][0] = this.valoare_fata[0];
	    
	    for (Zar vecin : zar_sursa.expand(N, M)) {
	    	
	    	coada.add(vecin);
	    	this.costuri_pozitii[vecin.getPozitie().getX()]
	    						[vecin.getPozitie().getY()][0] = vecin.getCost();
	    	
	    }
	   
	    
	    while (!coada.isEmpty()) {
	    	
	    	Zar zar_curent = coada.poll();
	    	
	    	int pozitie = (contains(pozitii_vizitate[zar_curent.getPozitie().getX()]
	    					[zar_curent.getPozitie().getY()], zar_curent.codificare()));
	    	
	    	// daca zarul actual nu a mai trecut prin pozitia pe care vrea sa treaca
	    	
	    	if (pozitie != -1) {
	    		
	    		// se parcurg toti vecini
	    		
	    		for (Zar vecin : zar_curent.expand(N, M)) {
	    				
	    			// si verificam daca costul se potriveste in vre-un "univers".
	    			// daca e mai mic decat vreunul dintr-un "univers".
	    			
	    			for (int i = 0; i < U; i++)
	    			
	    				if (this.costuri_pozitii[vecin.getPozitie().getX()]
	    										[vecin.getPozitie().getY()][i] 
	    										> zar_curent.getCost() + vecin.getFataSUS()) {
	    				
	    					this.costuri_pozitii[vecin.getPozitie().getX()]
	    										[vecin.getPozitie().getY()][i] = 
	    										zar_curent.getCost() + vecin.getFataSUS();
	    					coada.add(vecin);
	    					break;
	    		
	    				} 
	    		
	    		} 
	    	
	    		pozitii_vizitate[zar_curent.getPozitie().getX()]
	    						[zar_curent.getPozitie().getY()][pozitie] 
	    								= zar_curent.codificare();
	    	
	    	}
	    	
	    }
	    
	    // afisam minimul in fisier
	    
	    FileWriter fisier = new FileWriter("zar.out");
	    BufferedWriter write = new BufferedWriter(fisier);
	    
	    // minimul se va afla mereu pe prima pozitie
	    
	    write.write(costuri_pozitii[destinatie.getX()][destinatie.getY()][0] + "\n");
	    
	    write.close();

	}
	
	public static void main(String[] args) throws IOException {
		
		int N, M;
		int[] valoare_fata = new int[6];
		
		File fisier = new File("zar.in");
		Scanner read = new Scanner(fisier);
		
		// se citeste dimensiunea matricii
		
		N = read.nextInt();
		M = read.nextInt();
		
		// se citesc valorile fetelor zarului
		
		for (int i = 0; i < 6; i++)
			valoare_fata[i] = read.nextInt();
		
		int x, y;
		
		// se citesc coordonatele sursei si ale destinatiei
		
		x = read.nextInt();
		y = read.nextInt();
		Pozitie sursa = new Pozitie(x, y);
		
		x = read.nextInt();
		y = read.nextInt();
		Pozitie destinatie = new Pozitie(x, y);		
		
		read.close();
		
		MainZar main = new MainZar(N, M, valoare_fata, sursa, destinatie);
		
		main.explorare();
		
	}
	
}
