/**
 * 
 * Clasa pentru o pozitie din matrice.
 * 
 * @author Stancu Florin
 * 325CB
 *
 */

public class Pozitie implements Cloneable {

	private int x;
	private int y;
	
	public Pozitie(int x, int y) {
		
		this.x = x;
		this.y = y;
		
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public void setY(int y) {
		this.y = y;
	}
	
	@Override
	public boolean equals(Object other) {
		
	    if (other == null) return false;
	    if (other == this) return true;
	    if (!(other instanceof Pozitie)) return false;
	    
	    Pozitie p = (Pozitie)other;
	    if (this.x == p.getX() && this.y == p.getY())
	    	return true;
	    else
	    	return false;
	    
	}
	
	@Override
	public String toString() {
		return "[" + this.x + ", " + this.y + "]";
	}
	
	@Override
	public Pozitie clone() {
		try {
			final Pozitie result = (Pozitie)super.clone();
            // copy fields that need to be copied here!
			return result;
		} catch (final CloneNotSupportedException ex) {
            throw new AssertionError();
        }
	}
	
}
