enum Mutare {
	stanga,
	dreapta,
	sus,
	jos
};