import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * 
 * Clasa principala pentru prima problema.
 * 
 * @author Stancu Florin
 * 325CB
 *
 */

public class Fotbal {
	
	private int[] puncte_stranse;
	private int[][] partide_ramase_de_jucat;
	private int[] intrebari;
	private int N;
	private int Q;
	private int K;
	
	final static int NONE = -1;
	
	/**
	 * 
	 * Constructor principal.
	 * 
	 * @param N
	 * Numarul de echipe.
	 * 
	 * @param Q
	 * Numarul de intrebari.
	 * 
	 * @param K
	 * Numarul de partide.
	 * 
	 * @param puncte_stranse
	 * Vector cu punctele stranse de fiecare echipa.
	 * 
	 * @param partide_ramase_de_jucat
	 * Matrice cu numarul de meciuri ramase de jucata cu fiecare echipa in parte.
	 * 
	 * @param intrebari
	 * Vector cu intrebari.
	 * 
	 */
	
	public Fotbal(int N, int Q, int K, int[] puncte_stranse, int[][] partide_ramase_de_jucat, 
			int[] intrebari) {
		
		this.N = N;
		this.Q = Q;
		this.K = K;
		this.puncte_stranse = puncte_stranse;
		this.partide_ramase_de_jucat = partide_ramase_de_jucat;
		this.intrebari = intrebari;
		
	}
	
	/**
	 * 
	 * Metoda care returneaza calea de la sursa la destinatie.
	 * Utilizand un algoritm BFS.
	 * 
	 * @param g
	 * Graful in care se cauta aceasta cale.
	 * 
	 * @param u
	 * Nodul sursa.
	 * 
	 * @param v
	 * Nodul destiantie.
	 * 
	 * @return
	 * Un vector cu calea de la sursa la destinatie.
	 * 
	 */
	
	public static ArrayList<Integer> bfs(Graph g, int u, int v) {
		
		/* Ne vom folosi de vectorul de parinti pentru a spune daca un nod a fost
		 * adaugat sau nu in coada. */

		ArrayList<Integer> parent = new ArrayList<Integer>(g.getSize());
		for (int i = 0; i < g.getSize(); ++i) {
			parent.add(NONE);
		}

		LinkedList<Integer> q = new LinkedList<Integer>();
		q.add(u);

		while (parent.get(v) == NONE && q.size() > 0) {

			int node = q.get(0);
			q.remove(0);

			for (int i = 0; i < g.getSize(); ++i) {
				if (g.capacityMatrix[node][i] > 0 && parent.get(i) == NONE) {
					parent.set(i, node);
					q.add(i);
				}
			}
		}

		/* Daca nu s-a atins destinatia, atunci nu mai exista drumuri de crestere. */

		if (parent.get(v) == NONE) {
			return new ArrayList<Integer>(0);
		}

		/* Reconstituim drumul de la destinatie spre sursa. */
		ArrayList<Integer> returnValue = new ArrayList<Integer>();
		for (int node = v; ; node = parent.get(node)) {
			returnValue.add(0, node);

			if (node == u) {
				break;
			}
		}

		return returnValue;
		
	}
	
	/**
	 * 
	 * Metoda care satureaza graful.
	 * 
	 * @param g
	 * Graful pe care vrem sa-l saturam.
	 * 
	 * @param path
	 * Calea de la sursa la destinatie.
	 * 
	 * @return
	 * Fluxul cu care am saturat graful.
	 * 
	 */
	
	public static int saturate_path(Graph g, ArrayList<Integer> path) {

		/* Niciodata nu ar trebui sa se intample asta pentru ca sursa si destinatia
		 * sunt noduri distincte si cel putin unul dintre ele se afla in path. */

		if (path.size() < 2) {
			return 0;
		}

		/* Determinam fluxul maxim prin drum. */
		int flow = g.capacityMatrix[path.get(0)][path.get(1)];
		for (int i = 0; i < path.size() - 1; ++i) {

			int u = path.get(i), v = path.get(i + 1);

			/* TODO - Determinati fluxul in functie de capacitata muchiei (u, v) */
		      
			if (flow > g.capacityMatrix[u][v]) {
				flow = g.capacityMatrix[u][v];
			} 
		      
		}

		/* Si il saturam in graf. */
		for (int i = 0; i < path.size() - 1; ++i) {
			
			int u = path.get(i), v = path.get(i + 1);

			/* TODO - Modificati fluxul in functie de capacitatea muchiei (u, v) */
		      
			g.capacityMatrix[u][v] -= flow;
			g.capacityMatrix[v][u] = g.capacityMatrix[u][v] * (-1);

		      
		}

		/* Raportam fluxul cu care am saturat graful. */
		return flow;
		    
	}
	
	/**
	 * 
	 * Metoda care calculeaza fluxul maxim din graf.
	 * 
	 * @param g
	 * Graful pentru care vrem sa calculam fluxul maxim.
	 * 
	 * @param u
	 * Nodul sursa.
	 * 
	 * @param v
	 * Nodul destinatie.
	 * 
	 * @return
	 * Fluxul maxim calculat.
	 * 
	 */
	
	public static int maxFlow(Graph g, int u, int v) {
		
		int maxFlow = 0;

		/* Vom incerca in mod repetat sa determinam drumuri de crestere folosind
		 * BFS si sa le saturam pana cand nu mai putem determina un astfel de drum in
		 * graf. */

		while (true) {

			/* Determina drum de crestere. */
			ArrayList<Integer> saturation_path = bfs(g, u, v);

			/* TODO - In functie de saturation_path determinati daca fluxul trebuie
			 * marit sau trebuie iesit din while */
		      
			if (saturation_path.isEmpty())
				break;
		      
			maxFlow += saturate_path(g, saturation_path);
		      
		}

		return maxFlow;
		  
	}
	
	/**
	 * 
	 * Metoda care verifica daca o echipa poate sau nu castiga campionatul.
	 * 
	 * @param echipa
	 * Echipa pentru care dorim sa vedem daca poate castiga campionatul.
	 * 
	 * @return
	 * true / false dupa caz
	 * 
	 */
	
	public boolean afla_raspuns_pentru_intrebare(int echipa) {
		
		// maximul de puncte pe care poate sa le aiba echipa la finalul clasementului
		int maxim_puncte = puncte_stranse[echipa]; 	
		for (int i = 0; i < N; i++)
			if (i != echipa) {
				maxim_puncte += 2 * partide_ramase_de_jucat[echipa][i];
			}
		
		// media aritmetica a punctajelor tuturor echipelor mai putin echipa noastra
		double ma = ((2 * K * N * (N - 1) / 2) - maxim_puncte) / (N - 1);
		if (ma >= maxim_puncte) return false;
		
		/* Calculam punctele pe care nu trebuie sa le depaseasca (in urma urmatoareleor 
		 * meciuri) echipele adverse, pentru ca echipa noastra sa castige campionatul.
		 */
		
		int[] puncte_necesare = new int[N];
		for (int i = 0; i < N; i++)
			if (i != echipa) {
				puncte_necesare[i] = maxim_puncte - puncte_stranse[i];
				
				/* Daca o echipa are deja mai multe puncte decat maximul pe care
				 * ecipa noastra poate sa-l obtina, atunci nu se mai poate castiga
				 * campionatul
				 */
				
				if (puncte_necesare[i] < 0) return false;
			
			} else
				puncte_necesare[i] = -1;

		int dimensiune_subset = N - 1;
		int dimensiune_graf = dimensiune_subset + 
								dimensiune_subset * (dimensiune_subset - 1) / 2 + 2;
		
		/* Facem un vector cu echipele adverse echipei noastre. */
		
		int[] subset = new int[dimensiune_subset];
		int k = 0;
		for (int i = 0; i < N; i++)
			if (i != echipa) {
				subset[k] = i;
				k++;
			}
		
		/* Incepem a construi graful. */
		
		Graph g = new Graph(dimensiune_graf, Graph.Type.DIRECTED);
		
		int indice_nod = dimensiune_subset;
		
		int numar_meciuri_adverse = 0;
		
		for (int i = 0; i < dimensiune_subset - 1; i++)
			for (int j = i + 1; j < dimensiune_subset; j++) {
				
				indice_nod++;
				numar_meciuri_adverse += partide_ramase_de_jucat[subset[i]][subset[j]];
				
				g.addEdge(0, indice_nod, partide_ramase_de_jucat[subset[i]][subset[j]]);
				g.addEdge(indice_nod, i + 1, partide_ramase_de_jucat[subset[i]][subset[j]]);
				g.addEdge(indice_nod, j + 1, partide_ramase_de_jucat[subset[i]][subset[j]]);
				
			}
		
		for (int i = 0; i < dimensiune_subset; i++)
			g.addEdge(i + 1, dimensiune_graf - 1, puncte_necesare[subset[i]]);

		int flux = maxFlow(g, 0, dimensiune_graf - 1);

		if (flux == numar_meciuri_adverse) return true;
		
		return false;
		
	}
	
	/**
	 * 
	 * Metoda care verifica si afiseaza daca fiecare echipa din setul de
	 * intrebari poaate sau nu castiga campionatul.
	 * 
	 * @throws IOException
	 */
	
	public void afisare() throws IOException {
		
	    FileWriter fisier = new FileWriter("fotbal.out");
	    BufferedWriter write = new BufferedWriter(fisier);
	    
	    for (int i = 0; i < Q; i++)
	    	if (afla_raspuns_pentru_intrebare(intrebari[i]))
	    		write.write("TRUE\n");
	    	else
	    		write.write("FALSE\n");
	    
	    write.close();
		
	}
	
	/**
	 * 
	 * Metoda main.
	 * 
	 * @param args
	 * Lista de argumente.
	 * 
	 * @throws IOException
	 * 
	 */
	
	public static void main(String[] args) throws IOException {
		
		int N, P, K, Q;
		
		File fisier = new File("fotbal.in");
		Scanner read = new Scanner(fisier);
		
		N = read.nextInt();
		P = read.nextInt();
		K = read.nextInt();
		Q = read.nextInt();
		
		int[] puncte_stranse = new int[N];
		int[][] partide_ramase_de_jucat = new int[N][N];
		
		int index_echipa_1;
		int index_echipa_2;
		String rezultat;
		
		// se initializeaza matricea de partide jucate
		
		for (int i = 0; i < N; i++)
			for (int j = 0; j < N; j++)
				if (i != j)
					partide_ramase_de_jucat[i][j] = K;
				else
					partide_ramase_de_jucat[i][j] = -1;
		
		// se citesc partidele jucate
		
		for (int i = 0; i < P; i++) {
			
			index_echipa_1 = read.nextInt();
			index_echipa_2 = read.nextInt();
			rezultat = read.next();
			
			if (rezultat.equals("WIN"))
				puncte_stranse[index_echipa_1] += 2;
			else if (rezultat.equals("DRAW")) {
				puncte_stranse[index_echipa_1]++;
				puncte_stranse[index_echipa_2]++;
			}
			
			partide_ramase_de_jucat[index_echipa_1][index_echipa_2]--;
			partide_ramase_de_jucat[index_echipa_2][index_echipa_1]--;
			
		}
		
		// se citesc intrebarile
		
		int[] intrebari = new int[Q];
		
		for (int i = 0; i < Q; i++)
			intrebari[i] = read.nextInt();
		
		read.close();
		
		Fotbal clasament = new Fotbal(N, Q, K, puncte_stranse, 
										partide_ramase_de_jucat, intrebari);
		
		clasament.afisare();
		
	}
	
}
