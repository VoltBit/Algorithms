import java.util.ArrayList;

/**
 * 
 * Clasa pentru un o stare a unui zar.
 * 
 * @author Stancu Florin
 * 325CB
 *
 */

public class Zar implements Cloneable {
	
	private Pozitie pozitie; // pozitia zarului in matrice
	
	// descrierea zarului in spatiu
	
	private int sus;
	private int jos;
	private int fata;
	private int spate;
	private int stanga;
	private int dreapta;
	
	private int cost;
	private Zar parinte;
	
	/**
	 * 
	 * Constructor principal. Il folosesc doar cand creez zarul sursa.
	 * Celelalte zaruri sunt clone dupa acesta.
	 * 
	 * @param pozitie
	 * Pozitia sursei.
	 * 
	 * @param zar
	 * Un vector cu costurile pentru fiecare fata a zarului.
	 * 
	 * Exemplu: [sus, fata, dreapta, stanga, spate, jos]
	 * 
	 */
	
	public Zar (Pozitie pozitie, int[] zar) {
		
		this.pozitie = pozitie;

		this.sus = zar[0];
		this.jos = zar[5];
		this.fata = zar[1];
		this.spate = zar[4];
		this.stanga = zar[3];
		this.dreapta = zar[2];

		this.cost = this.sus;
		
	}
	
	/**
	 * 
	 * Metoda care-mi rostogoleste zarul actual.
	 * 
	 * @param m
	 * Directia catre care vrem sa-l rostogolim.
	 * 
	 */
	
	public void rostogolire(Mutare m) {
		
		int aux;
		
		if (m == Mutare.dreapta) {
			
			aux = this.dreapta;
			this.dreapta = this.sus;
			this.sus = this.stanga;
			this.stanga = this.jos;
			this.jos = aux;
			
			this.pozitie.setY(this.pozitie.getY() + 1);
			
		} else if (m == Mutare.stanga) {
			
			aux = this.stanga;
			this.stanga = this.sus;
			this.sus = this.dreapta;
			this.dreapta = this.jos;
			this.jos = aux;
			
			this.pozitie.setY(pozitie.getY() - 1);
			
		} else if (m == Mutare.sus) {
			
			aux = this.spate;
			this.spate = this.sus;
			this.sus = this.fata;
			this.fata = this.jos;
			this.jos = aux;
			
			this.pozitie.setX(pozitie.getX() - 1);
			
		} else if (m == Mutare.jos) {
			
			aux = this.fata;
			this.fata = this.sus;
			this.sus = this.spate;
			this.spate = this.jos;
			this.jos = aux;
			
			this.pozitie.setX(this.pozitie.getX() + 1);
			
		}
		
		this.cost = this.sus;
		
	}
	
	public void setPozitie(Pozitie pozitie) {
		this.pozitie = pozitie;
	}
	
	public Pozitie getPozitie() {
		return this.pozitie;
	}
	
	public int getFataSUS() {
		return this.sus;
	}
	
	/**
	 * 
	 * Metodaca care-mi codifica starea actuala a zarului.
	 * Foloseste hashcode() pe un vector al costurilor fetelor.
	 * 
	 * @return
	 * Un integer reprezentand codificarea unica a acestuia.
	 * 
	 */
	
	public int codificare() {
		
		ArrayList<Integer> fete = new ArrayList<Integer>();
		
		fete.add(this.sus);
		fete.add(this.jos);
		fete.add(this.stanga);
		fete.add(this.dreapta);
		fete.add(this.fata);
		fete.add(this.spate);
		
		return fete.hashCode();
		
	}
	
	@Override
	public Zar clone() {
		try {
			final Zar result = (Zar)super.clone();
            result.setPozitie(this.pozitie.clone());
			return result;
		} catch (final CloneNotSupportedException ex) {
            throw new AssertionError();
        }
	}
	
	@Override
	public boolean equals(Object other) {
		
	    if (other == null) return false;
	    if (other == this) return true;
	    if (!(other instanceof Zar)) return false;
	    
	    Zar z = (Zar)other;
	    if (this.pozitie.equals(z.getPozitie()))
	    	return true;
	    else
	    	return false;
	    
	}
	
	/**
	 * 
	 * Metoda care-mi returneaza starile in care poate ajunge zarul actual.
	 * 
	 * @param N
	 * Numarul de linii ale matricii.
	 * 
	 * @param M
	 * Numarul de coloane ale matricii.
	 * 
	 * @return
	 * Un vector cu starile in care poate ajunge.
	 * 
	 */
	
	public ArrayList<Zar> expand(int N, int M) {
		
		ArrayList<Zar> vecini = new ArrayList<Zar>();
		
		Zar vecin;
		
		// vecinul de sus
		
		if (this.pozitie.getX() != 0) {
			
			vecin = this.clone();
			vecin.rostogolire(Mutare.sus);
			vecin.setParinte(this);
			
			if (this.parinte == null)
				vecini.add(vecin);
			else if (!vecin.getPozitie().equals(this.parinte.getPozitie()))
				vecini.add(vecin);
			
		}
		
		// vecinul de jos
		
		if (this.pozitie.getX() != N - 1) {
			
			vecin = this.clone();
			vecin.rostogolire(Mutare.jos);
			vecin.setParinte(this);
			
			if (this.parinte == null)
				vecini.add(vecin);
			else if (!vecin.getPozitie().equals(this.parinte.getPozitie()))
				vecini.add(vecin);
			
		}
		
		// vecinul din stanga
		
		if (this.pozitie.getY() != 0) {
			
			vecin = this.clone();
			vecin.rostogolire(Mutare.stanga);
			vecin.setParinte(this);
			
			if (this.parinte == null)
				vecini.add(vecin);
			else if (!vecin.getPozitie().equals(this.parinte.getPozitie()))
				vecini.add(vecin);
			
		}
		
		// vecinul din dreapta
		
		if (this.pozitie.getY() != M - 1) {
			vecin = this.clone();
			vecin.rostogolire(Mutare.dreapta);
			vecin.setParinte(this);
			
			if (this.parinte == null)
				vecini.add(vecin);
			else if (!vecin.getPozitie().equals(this.parinte.getPozitie()))
				vecini.add(vecin);
			
		}
		
		return vecini;
		
	}
	
	@Override
	public String toString() {
		return this.pozitie + " : " + 
				"\n\tSus: " + this.sus +
				"\n\tJos: " + this.jos +
				"\n\tStanga: " + this.stanga + 
				"\n\tDreapta: " + this.dreapta +
				"\n\tFata: " + this.fata + 
				"\n\tSpate: " + this.spate + 
				"\n\t\tCost: " + this.cost;
	}
	
	public int getCost() {
		return this.cost;
	}
	
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	/**
	 * 
	 * Metoda care-mi seteaza parintele unui zar.
	 * In momentul in care este setat parintele, se modifica si costul
	 * zarului actual in functie de cel al parintelui.
	 * 
	 * @param parinte
	 * Parintele zarului actual.
	 * 
	 */
	
	public void setParinte(Zar parinte) {
		
		this.parinte = parinte;
		this.cost += parinte.getCost();
		
	}
	
	public Zar getParinte() {
		return this.parinte;
	}
	
}
