package pc_lab7;


public class PC_lab7 {
    public static void run(String[] args) {
        
    }

}
